import tkinter as tk
from tkinter import messagebox
import webbrowser

# Dummy user database (for demonstration purposes)
users = {
    "admin": "password123",
    "user1": "securepass",
    # Add more users as needed
}

def show_rules():
    messagebox.showinfo("Rules", "1. No Hacking")

def open_discord():
    webbrowser.open("https://discord.com/invite/q6HgRZpURB")

def login():
    username = username_entry.get()
    password = password_entry.get()
    if username in users and users[username] == password:
        messagebox.showinfo("Login Successful", f"Welcome, {username}!")
    else:
        messagebox.showerror("Login Failed", "Invalid username or password")

def signup():
    username = username_entry.get()
    password = password_entry.get()
    if username not in users:
        users[username] = password
        messagebox.showinfo("Sign-Up Successful", f"Account created for {username}")
    else:
        messagebox.showerror("Sign-Up Failed", "Username already exists")

def change_page(selected_page):
    # Hide all frames
    home_frame.pack_forget()
    # Add logic to show the selected page based on the value of selected_page
    if selected_page == "Home":
        home_frame.pack(fill="both", expand=True)
    # Add more pages here as needed

# Create the main window
root = tk.Tk()
root.title("No V4.2 Beta")
root.geometry("400x300")

# Create a frame for the "Home" page
home_frame = tk.Frame(root, bg="red")

# Add text labels to the "Home" page
welcome_label = tk.Label(home_frame, text="Welcome To No", font=("Helvetica", 20, "bold"), bg="red")
welcome_label.pack(pady=20)

by_label = tk.Label(home_frame, text="By The No Team", font=("Helvetica", 12), bg="red")
by_label.pack()

# Create entry fields for username and password
username_label = tk.Label(home_frame, text="Username:")
username_label.pack()
username_entry = tk.Entry(home_frame)
username_entry.pack()

password_label = tk.Label(home_frame, text="Password:")
password_label.pack()
password_entry = tk.Entry(home_frame, show="*")
password_entry.pack()

# Create login and sign-up buttons
login_button = tk.Button(home_frame, text="Login", bg="green", command=login)
login_button.pack(pady=10)

signup_button = tk.Button(home_frame, text="Sign Up", bg="orange", command=signup)
signup_button.pack(pady=10)

# Create a blue button called "Discord"
discord_button = tk.Button(home_frame, text="Discord", bg="blue", command=open_discord)
discord_button.pack(pady=10)

# Create a dropdown box for selecting pages
pages = ["Home"]  # Add more pages as needed
selected_page_var = tk.StringVar()
selected_page_var.set(pages[0])  # Set default value to "Home"
page_dropdown = tk.OptionMenu(root, selected_page_var, *pages, command=change_page)
page_dropdown.pack()

# Show the initial "Home" page
home_frame.pack(fill="both", expand=True)

# Run the main event loop
root.mainloop()
