import tkinter as tk

# Function to change the text from 'No' to 'Yes:)'
def change_text():
    label.config(text="Yes:)")

# Create a new Tkinter application
app = tk.Tk()
app.title("No V4.1 Beta")

# Set the size of the window
app.geometry("400x300")

# Set the background color to red
app.configure(bg='red')

# Create a label with white text 'No'
label = tk.Label(app, text="No", bg='red', fg='white', font=('Helvetica', 24))
label.pack(side='left', padx=10)

# Create a blue button that changes the text when clicked
button = tk.Button(app, text="Change to Yes:)", bg='blue', fg='white', command=change_text)
button.pack(side='left', padx=10)

# Run the application
app.mainloop()

# The app with a red background, white text 'No', and a blue button has been created and is running.
