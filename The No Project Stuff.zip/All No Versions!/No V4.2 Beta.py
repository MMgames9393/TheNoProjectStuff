import tkinter as tk
from tkinter import messagebox

# Create the main window
root = tk.Tk()
root.title("No V4.2 Beta")
root.geometry("400x300")

# Create a frame for the "Home" page
home_frame = tk.Frame(root, bg="red")
home_frame.pack(fill="both", expand=True)

# Add text labels to the "Home" page
welcome_label = tk.Label(home_frame, text="Welcome To No", font=("Helvetica", 20, "bold"), bg="red")
welcome_label.pack(pady=20)

by_label = tk.Label(home_frame, text="By The No Team", font=("Helvetica", 12), bg="red")
by_label.pack()

# Create a red button called "Rules"
def show_rules():
    messagebox.showinfo("Rules", "1. No Hacking")

rules_button = tk.Button(home_frame, text="Rules", bg="red", command=show_rules)
rules_button.pack(pady=20)

# Run the main event loop
root.mainloop()
