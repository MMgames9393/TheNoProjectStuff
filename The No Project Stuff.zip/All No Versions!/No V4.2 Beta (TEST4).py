import tkinter as tk
from tkinter import messagebox
import webbrowser

# Dummy user database (for demonstration purposes)
users = {
    "admin": "password123",
    "user1": "securepass",
    # Add more users as needed
}

def show_rules():
    messagebox.showinfo("Rules", "1. No Hacking")

def open_discord():
    webbrowser.open("https://discord.com/invite/q6HgRZpURB")

def login():
    username = username_entry.get()
    password = password_entry.get()
    if username in users and users[username] == password:
        messagebox.showinfo("Login Successful", f"Welcome, {username}!")
        # Add logic to navigate to other pages after successful login
    else:
        messagebox.showerror("Login Failed", "Invalid username or password")

def signup():
    username = username_entry.get()
    password = password_entry.get()
    if username not in users:
        users[username] = password
        messagebox.showinfo("Sign-Up Successful", f"Account created for {username}")
        # Add logic to navigate to other pages after successful sign-up
    else:
        messagebox.showerror("Sign-Up Failed", "Username already exists")

def change_page(selected_page):
    # Hide all frames
    login_frame.pack_forget()
    signup_frame.pack_forget()
    # Add logic to show the selected page based on the value of selected_page
    if selected_page == "Login":
        login_frame.pack(fill="both", expand=True)
    elif selected_page == "Sign Up":
        signup_frame.pack(fill="both", expand=True)

# Create the main window
root = tk.Tk()
root.title("No V4.2 Beta")
root.geometry("400x300")

# Create frames for login and sign-up pages
login_frame = tk.Frame(root, bg="red")
signup_frame = tk.Frame(root, bg="red")

# Add text labels and entry fields to the login page
# Similar setup for the sign-up page

# Create a dropdown box for selecting pages
pages = ["Login", "Sign Up"]  # Add more pages as needed
selected_page_var = tk.StringVar()
selected_page_var.set(pages[0])  # Set default value to "Login"
page_dropdown = tk.OptionMenu(root, selected_page_var, *pages, command=change_page)
page_dropdown.pack()

# Show the initial login page
login_frame.pack(fill="both", expand=True)

# Run the main event loop
root.mainloop()
